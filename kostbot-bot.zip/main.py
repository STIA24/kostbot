from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext
from keep_alive import keep_alive
import os

TOKEN = os.getenv("BOT_TOKEN")
keep_alive()

def start(update: Update, context: CallbackContext) -> None:
    reply_keyboard = [['Info Kost', 'Harga Kost'], ['Fasilitas', 'Lokasi'], ['Hubungi Admin']]
    update.message.reply_text(
        "Halo! Pilih menu di bawah ini:",
        reply_markup=ReplyKeyboardMarkup(reply_keyboard, resize_keyboard=True)
    )

def reply_handler(update: Update, context: CallbackContext) -> None:
    txt = update.message.text.lower()
    if 'info' in txt:
        update.message.reply_text("🏡 Kost Nyaman Express — Aman, bersih, strategis.")
    elif 'harga' in txt:
        update.message.reply_text("💸 Harga mulai Rp 530.000/bln (sudah termasuk listrik & air).")
    elif 'fasilitas' in txt:
        update.message.reply_text("✨ Fasilitas: WiFi, kamar mandi luar, jemuran, parkir motor.")
    elif 'lokasi' in txt:
        update.message.reply_text(
            "📍 Jl. Nusa Jaya Gg. Mushola No. 32, Pd. Ranji, Ciputat Timur (samping masjid).\n"
            "[Klik Maps](https://maps.app.goo.gl/LgDyakWdAzQSKohE7)",
            parse_mode='Markdown'
        )
    elif 'hubungi' in txt or 'admin' in txt:
        update.message.reply_text("📲 WA Admin: wa.me/6283890048151")
    else:
        update.message.reply_text("Pilih menu di keyboard ya 😊")

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, reply_handler))
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()